import java.util.Scanner;

public class Q_1 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int a = 40;
        int b = 23;
        int c = 45;
        int sum = a + b + c;
        System.out.println("The sum is " + sum);
        
    }
}