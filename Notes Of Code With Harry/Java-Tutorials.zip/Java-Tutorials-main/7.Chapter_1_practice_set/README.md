# Java Tutorial: Chapter 1- Practice Set | Java Practice Problems With Solution

### Chapter 1 – Practice Set

1. Write a program to sum three numbers in Java.
2. Write a program to calculate CGPA using marks of three subjects (out of 100)
3. Write a Java program that asks the user to enter his/her name and greets them with “Hello <name>, have a good day” text.
4. Write a Java program to convert Kilometers to miles.
5. Write a Java program to detect whether a number entered by the user is an integer or not.
  
### Handwritten Notes: [Click To Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-7/JavaChapter1PracticeSet.pdf)

### Ultimate Java Cheatsheet: [Click To Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-7/UltimateJavaCheatSheet.pdf)
