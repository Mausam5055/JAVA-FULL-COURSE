import java.util.Scanner;

public class Q_2 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        float subject1 = 45;
        float subject2 = 95;
        float subject3 = 48;
        float cgpa = (subject1 + subject2 +subject3)/30;
        System.out.println("The CGPA is " + cgpa);
        
    }
}