import java.util.*;

public class cwh_25_ch5_ps_pr_03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i=1; i<11; i++) {
            System.out.println(n + " * " + i + " = " + (n*i));
        }
    }
}