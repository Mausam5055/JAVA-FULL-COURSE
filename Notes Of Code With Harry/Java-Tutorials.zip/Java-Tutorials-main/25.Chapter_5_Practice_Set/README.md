# Java tutorial: Practice Questions on Loops

**Question 1:** Write a program to print the following pattern :
```
****

***

**

*
```
**Question 2:** Write a program to sum first n even numbers using a while loop.

**Question 3:** Write a program to print the multiplication table of a given number n.

**Question 4:** Write a program to print a multiplication table of 10 in reverse order.

**Question 5:** Write a program to find the factorial of a given number using for loops.

**Question 6:** Repeat problem 5 using a while loop.

**Question 7:** Repeat problem 1 using for/while loop.

**Question 8:** What can be done using one type of loop can also be done using the other two types of loops - True or False.

**Question 9:** Write a program to calculate the sum of the numbers occurring in the multiplication table of 8.

**Question 10:** A do-while loop is executed:

    At least once
    At least twice
    At most once
**Question 11:** Repeat problem 2 using for loop.

**Handwritten Notes: [Click to Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-25/Chapter_5__Practice_Set.pdf)**

**Ultimate Java Cheatsheet: [Click To Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-25/UltimateJavaCheatSheet.pdf)**
