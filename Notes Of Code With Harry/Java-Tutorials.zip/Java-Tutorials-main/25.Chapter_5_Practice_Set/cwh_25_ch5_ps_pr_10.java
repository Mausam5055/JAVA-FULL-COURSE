public class cwh_25_ch5_ps_pr_10 {
    public static void main(String[] args) {
        System.out.println("The while loop executes at least once");
    }
}