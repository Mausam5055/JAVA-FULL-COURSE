public class cwh_25_ch5_ps_pr_09 {
    public static void main(String[] args) {
        int n = 8;
        int sum = 0;
        for (int i=1; i<=10; i++) {
            sum += n*i;
        }
        System.out.println(sum);
    }
}