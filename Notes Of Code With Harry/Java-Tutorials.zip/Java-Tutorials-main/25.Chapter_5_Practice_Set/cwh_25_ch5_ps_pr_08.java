import java.util.*;

public class cwh_25_ch5_ps_pr_08 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // The answer is True.
    }
}