package com.company;

public class CWH_04_literals {
    public static void main(String[] args) {
        byte age = 34;
        int age2 = 56;
        short age3 = 87;
        long ageDino = 5666666666666L;
        char ch = 'A';
        float f1 = 5.6f;
        double d1 = 4.66;
        boolean a = true;
        String str = "Harry";
        
        System.out.print(age);
        System.out.println(str);
    }
}
