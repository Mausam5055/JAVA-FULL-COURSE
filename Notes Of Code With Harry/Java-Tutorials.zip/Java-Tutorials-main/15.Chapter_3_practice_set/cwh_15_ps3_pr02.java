public class cwh_15_ps3_pr02 {
    public static void main(String[] args) {
        String name = "My name is            Kishan       ";
        System.out.println(name);
        
        name = name.replace(" ", "_");
        System.out.println(name);
    }
}