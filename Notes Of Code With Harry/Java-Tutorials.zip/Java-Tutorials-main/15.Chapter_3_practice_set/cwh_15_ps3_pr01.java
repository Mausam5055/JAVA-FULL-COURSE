public class cwh_15_ps3_pr01 {
    public static void main(String[] args) {
        String name = "Peter Parker";
        System.out.println(name);
        
        name = name.toLowerCase();
        System.out.println(name);
    }
}