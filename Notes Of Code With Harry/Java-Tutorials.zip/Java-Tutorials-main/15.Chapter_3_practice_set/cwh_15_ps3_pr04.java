public class cwh_15_ps3_pr04 {
    public static void main(String[] args) {
        String name = "My name  is   Kishan";
        System.out.println(name.indexOf("  "));
        System.out.println(name.indexOf("   "));
    }
}