public class cwh_15_ps3_pr05 {
    public static void main(String[] args) {
        String Letter = ("Dear Harry,\n\t This Java Course is nice.\n\t Thanks");
        System.out.println(Letter);
    }
}