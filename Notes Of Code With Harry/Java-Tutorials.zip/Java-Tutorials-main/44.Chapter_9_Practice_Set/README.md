# Java Tutorial: Exercise on Access Modifiers and Constructors

1. create a class cylinder and use getter and setters to set its radius and height 
2. use ➊ to calculate surface and volume of the cylinder 
3. Use a constructor and repeat ➊
4. Overload a constructor used to initialize a rectangle of length and breath 5 for using custom parameters 
5. Repeat ➊ for a sphere

**Handwritten Notes: [Click to Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-44/Ch9PS.pdf)**

**Ultimate Java Cheatsheet: [Click To Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-44/UltimateJavaCheatSheet.pdf)**
