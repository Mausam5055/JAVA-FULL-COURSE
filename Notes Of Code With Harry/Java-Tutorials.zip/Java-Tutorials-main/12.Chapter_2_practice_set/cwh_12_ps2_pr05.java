import java.util.Scanner;

public class cwh_12_ps2_pr_05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(7*49/7+35/7);
    }
}