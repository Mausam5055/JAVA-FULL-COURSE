import java.util.Scanner;

public class cwh_12_ps2_pr_03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println(a>8);
    }
}
