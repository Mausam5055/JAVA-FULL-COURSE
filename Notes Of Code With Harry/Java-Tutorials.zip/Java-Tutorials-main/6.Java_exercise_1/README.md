# Java Programming Exercise 1: CBSE Board Percentage Calculator

### Exercise 1.1

- Write a program to calculate the percentage of a given student in the CBSE board exam. His marks from 5 subjects must be taken as input from the keyboard. (Marks are out of 100)

### Handwritten Notes: [Click To Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-6/JavaChapter1.pdf)

### Ultimate Java Cheatsheet:[Click To Download](https://api.codewithharry.com/media/videoSeriesFiles/courseFiles/java-tutorials-for-beginners-6/UltimateJavaCheatSheet.pdf)
