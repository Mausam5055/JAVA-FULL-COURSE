public class Total {
    public static void main(String args[]) {
      int x=10;
      int y=25;
      int z=63;
      int sum=x+y+z;

      System.out.println("Sum of x+y+z = " + sum);
    }
}
